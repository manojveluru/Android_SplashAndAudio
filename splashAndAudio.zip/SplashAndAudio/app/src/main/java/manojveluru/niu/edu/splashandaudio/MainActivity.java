package manojveluru.niu.edu.splashandaudio;
/********************************************************************
 CSCI 522 - Portfolio 10 - Semester (Spring) Year - 2019

 Programmer(s): Manoj Veluru
 Section: 1
 TA: Harshith Desamsetti
 Date Due: 02/27/2019

 Purpose: Image Gallery

 *********************************************************************/
import android.app.Activity;
import android.media.MediaPlayer;
import android.provider.MediaStore;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends Activity {

    private Button ukuleleBtn, drumsBtn;
    private MediaPlayer ukuleleMP, drumsMP;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //connect the Buttons to the screen
        ukuleleBtn = findViewById(R.id.ukeleleButton);
        drumsBtn = findViewById(R.id.drumButton);

        //Create the MediaPlayer for the ukulele MP3 and connect the audio
        ukuleleMP = new MediaPlayer();
        ukuleleMP = MediaPlayer.create(this, R.raw.ukulele);
        //Create the media player for the drums mp3 and connect the audio
        drumsMP = new MediaPlayer();
        drumsMP = MediaPlayer.create(this, R.raw.drums);
    }//end onCreate

    public void playUkulele(View view)
    {
        //if the ukulele MP# is curretly playing
        if(ukuleleMP.isPlaying())
        {
            //pause the media player for the ukulele
            ukuleleMP.pause();

            //change the label on the button to play
            ukuleleBtn.setText(R.string.playUkeleString);
        }
        else //ukulele MP3 is not playing
            {
                //Check to see if the drums MP3 is playing
                if(drumsMP.isPlaying())
                {
                    //pause the drums MP3
                    drumsMP.pause();

                    //change the label on the drums button to play
                    drumsBtn.setText(R.string.playDrumString);
                }

                //play the ukulele MP3
                ukuleleMP.start();

                //update the ukulele button label to pause
                ukuleleBtn.setText(R.string.pauseUkeleString);
            }
    }//end playUkulele

    public void playDrums(View view)
    {
        //if the drums MP# is currently playing
        if(drumsMP.isPlaying())
        {
            //pause the media player for the drums
            drumsMP.pause();

            //change the label on the button to play
            drumsBtn.setText(R.string.playDrumString);
        }
        else //drums MP3 is not playing
        {
            //Check to see if the ukulele MP3 is playing
            if(ukuleleMP.isPlaying())
            {
                //pause the ukulele MP3
                ukuleleMP.pause();

                //change the label on the ukulele button to play
                ukuleleBtn.setText(R.string.playUkeleString);
            }

            //play the drums MP3
            drumsMP.start();



            //update the drums button label to pause
            drumsBtn.setText(R.string.pauseDrumString);
        }
    }//end playDrums
}//end MainActivity
